# 招生工具平台前端启动指南

本指南为研发团队提供快速起服说明。当前架构已回滚并稳定在纯 **React + TailwindCSS + Vite**。

## 1. 源码启动 (推荐)

在 `frontend` 目录下，执行环境安装：
```bash
npm install
```

启动本地热更新服务器：
```bash
npm run dev
```
之后访问终端打印的 `http://localhost:5173/` 即可。

## 2. 静态产物包部署

如果你拿到的是 `frontend-dist.zip`，解压后包含的纯前端静态资产（即 `dist` 目录下的内容）。
可以使用任意静态服务器启动：
```bash
npx serve -s dist
```
或者将其放在 Nginx、Node 等后台服务的静态资源目录下直接访问。

**注意**：Vite 默认配置了 `base: './'` 且由于使用的是单页路由（SPA），请如果是二级目录代理，请按实际应用场景调整路由 `<BrowserRouter>` 的 `basename`。
